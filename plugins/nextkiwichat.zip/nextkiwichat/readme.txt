=== KiwiChat NextClient ===
Contributors: kiwichat, showchat
Tags: IRC, chat, webchat, kiwi, kiwiirc, nextclient, kiwiirc nextclient, embed, embedded, live chat, irc client, kiwichat
Donate link: https://showchat.tk
Requires at least: 5.0
Tested up to: 5.4
Requires PHP: 5.6
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

KiwiChat is an online chat client, your IRC client based on kiwiirc Add your networks. Join your channels.

== Description ==

How to use KiwiChat…
Allows you to embed a KiwiIRC IRC client with a shortcode.

== Frequently Asked Questions ==

Do you have something to say? Do you need help?
See the support wiki [Support Wiki](https://github.com/KiwiChat/NextKiwiChat/wiki "Support Wiki")
NextKiwiChat GitHub Page [KiwiChat GitHub](https://github.com/KiwiChat/NextKiwiChat "NextKiwiChat GitHub")

== Installation ==

1. Upload the "nextkiwichat" folder to the "/wp-content/plugins/" directory.
2. Activate the plugin through the "Plugins" menu in WordPress.
3. Configure your settings in the nextkiwichat.php
4. Place shortcode in your pages or posts:

`[nextkiwichat]` 

See the support wiki [Support Wiki](https://github.com/KiwiChat/NextKiwiChat/wiki "Support Wiki")

== Changelog ==

= 1.0 =
Initial release.

== Upgrade Notice ==

Stable version: 1.0